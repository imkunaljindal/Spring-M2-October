package com.example.CricBuzz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CricBuzzApplication {

	public static void main(String[] args) {
		SpringApplication.run(CricBuzzApplication.class, args);
	}

}
