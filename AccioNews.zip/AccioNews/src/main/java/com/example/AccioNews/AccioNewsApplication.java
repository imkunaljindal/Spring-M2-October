package com.example.AccioNews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccioNewsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccioNewsApplication.class, args);
	}

}
