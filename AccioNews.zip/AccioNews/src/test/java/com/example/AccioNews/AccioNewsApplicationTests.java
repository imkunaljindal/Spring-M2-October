package com.example.AccioNews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccioNewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
